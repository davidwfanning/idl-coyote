To use the Catalyst Library resources, it is best to copy them
into the $IDL_DIR/resource/bitmaps directory. They will not
interfere with any of the bitmaps currently located in that
directory from ITTVIS.