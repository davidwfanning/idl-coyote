Xcd is a program to change directories in IDL. See the comments at the
top of xcd.pro for additional discussion.

To invoke xcd, make sure the following files are in IDL's
search path, and type xcd at the IDL prompt.
 
idlexdirchanger__define.pro
idlexdirlisting__define.pro
idlexdirwidget__define.pro
xcd.pro
direxist.pro
get_devices.pro

Known problems:

1. Xcd does not work on Macintosh machines. (Perhaps it's not really 
needed on mac).

2. Xcd has been known to generate an unusably long droplist on some Unix
platforms. The droplist is so big it runs off the screen.  To get
around this problem, unix user's may want to hardcode a list of devices 
in place of the call to get_devices in function DirectoryChanger::init.

-Paul Sorenson
